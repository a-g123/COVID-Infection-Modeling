from tkinter import Tk, Frame, Button, scrolledtext, filedialog, END
import os, pickle

numbers = []
days = 0
people = None
cases = []

#opens the file the user is wants the data to be checked for
def open_file():
    global days, numbers, cases, people
    thefile = filedialog.askopenfilename(initialdir=os.getcwd(), filetypes=(('Text Files (*.txt)', '*.txt'),('All Files (*.*)', '*.*')))
    #configing the save function normal so the user can access it
    txtOutput.config(state='normal')
    btnSave.config(state='normal')
    #adding titles
    txtOutput.insert(END, f'{"TEST CASE":<20}{"DAY"}')
    #reading the text file
    with open(thefile, 'r') as reader:
        line = reader.readline().strip('\n')
        #going through the 10 cases
        for x in range(10):
            numbers = []
            #checking the first 3 numbers in the set of data
            for q in range(3):
                #adding 3 numbers into the list
                numbers.append(line)
                #goes to the next line
                line = reader.readline().strip('\n')
                if q == 2:
                    people = 0
                    days = 0
                    #calculating the number of days it takes for the cases to surpass a certain number
                    n = int(numbers[1])
                    #while the number of cases are not surpassed keep adding
                    while people <= int(numbers[0]):
                        people = n + (int(numbers[2])*n)
                        n = people
                        days += 1
                    #once the cases have surpassed the number of people add it to the list
                    cases.append(days)
    #adding the case numbers and days per case
    for x in range(10):
        txtOutput.insert(END, f'\n{x + 1:<20}{cases[x]}')
    txtOutput.config(state='disabled')

#this fucntion will save the binary files
def save_file():
    #user will select the file they want to add the data to
    thefile = filedialog.askopenfilename(initialdir=os.getcwd(), filetypes=(('Binary Files (*.bin)', '*.bin'),('All Files (*.*)', '*.*')))
    with open(thefile, 'wb') as writer:
        pickle.dump(cases, writer)
    
def exit_program():
    exit()

WINDOW_WIDTH, WINDOW_HEIGHT = 239, 231

root = Tk()
root.title('COVID Infection Modeling')
root.geometry(f'{WINDOW_WIDTH}x{WINDOW_HEIGHT}+{root.winfo_screenwidth() // 2 - WINDOW_WIDTH // 2}+{root.winfo_screenheight() // 2 - WINDOW_HEIGHT // 2}')

frame = Frame(root, padx=10, pady=10)
frame.pack()

txtOutput = scrolledtext.ScrolledText(frame, width=30, height=11, font=('Consolas 8'), padx=10, pady=10, state='disabled')
txtOutput.grid(row=0, column=0, pady=5)

buttonFrame = Frame(frame, pady=5)
buttonFrame.grid(row=1, column=0)

btnOpen = Button(buttonFrame, text='OPEN', width=8, command=open_file)
btnOpen.pack(side='left', padx=2)
btnSave = Button(buttonFrame, text='SAVE', width=8, state='disabled', command=save_file)
btnSave.pack(side='left', padx=2)
btnExit = Button(buttonFrame, text='EXIT', width=8, command=exit_program)
btnExit.pack(side='left', padx=2)

root.mainloop()